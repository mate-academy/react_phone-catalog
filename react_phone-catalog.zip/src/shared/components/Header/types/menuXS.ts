export type menuXs = {
    isVisible: number;
    onVisible: (value:number) => void;
}