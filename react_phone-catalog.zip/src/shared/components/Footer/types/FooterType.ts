export type FooterType = {
        id : number;
        to : string;
        label: string;
}