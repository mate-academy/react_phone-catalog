export type ProductTypeDescription = {
  title: string;
  text: string[];
}