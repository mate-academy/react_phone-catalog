

export type ProductPage = {
    id: number | string,
    category: string,
    itemId: string,
    name: string,
    fullPrice: number,
    price: number,
    screen: string,
    capacity: string,
    color: string,
    ram: string,
    year: number,
    image: string,
}