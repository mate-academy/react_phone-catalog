export type DeleteUrlParams = {
    urlParams: URLSearchParams;
    onUrlParams: (params: URLSearchParams) => void;
}