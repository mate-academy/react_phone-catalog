import './LoaderDetailsPage.css'

export const LoaderDetailsPage = () => {
    return (
        <div className="skeleton animating box big rectangle"></div>
    )
}