import './Items.scss'

export const Items = () => {
    return(
        <h1>Items</h1>
    )
}