
export type CategoryitemType = {
    // filtredCategory: object;
    name: string;
    total: string | number;
    img: string;
}