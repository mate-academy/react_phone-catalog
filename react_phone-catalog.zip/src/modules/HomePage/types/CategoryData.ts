
export type CategoryData = {
    name: string;
    count: (string | number);
    image: string;
}