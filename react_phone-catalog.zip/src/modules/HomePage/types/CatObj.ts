export type CatObj = {
    label: string;
    // number: number;
}