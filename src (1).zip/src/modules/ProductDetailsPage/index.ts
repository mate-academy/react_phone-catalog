export { ProductDetailsPage } from './ProductDetailsPage';
