import { NavigationItem } from '../../shared/types/NavLinkProps';
import { Logo } from '../../shared/ui/Logo';
import { NavList } from '../../shared/ui/nav__list';
import {
  FooterLabelProp,
  FooterNavName,
  FooterRoutePath,
} from './types/footerLinks';
import styles from './footer.module.scss';
import {
  ButtonsProps,
  ButtonNames,
  Path,
} from '../../shared/types/ButtonProps';
import { FooterButtons } from './components/footer-buttons';

export const Footer = () => {
  const linksList: NavigationItem[] = [
    {
      name: FooterNavName.Github,
      path: FooterRoutePath.Github,
      labelProp: FooterLabelProp.Github,
    },
    {
      name: FooterNavName.Contacts,
      path: FooterRoutePath.Contacts,
      labelProp: FooterLabelProp.Contacts,
    },
    {
      name: FooterNavName.Rights,
      path: FooterRoutePath.Rights,
      labelProp: FooterLabelProp.Rights,
    },
  ];

  const data: ButtonsProps = {
    name: ButtonNames.Top,
    path: Path.Up,
  };

  return (
    <footer className={styles.footer}>
      <Logo className={`${styles.footer__logo} footer__logo`} />
      <NavList key={'footer'} list={linksList} cN={`${styles.footer__nav}`} />
      <FooterButtons data={data} className={styles['footer__btn-container']} />
    </footer>
  );
};
