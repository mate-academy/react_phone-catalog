import { Link } from 'react-router-dom';
import styles from './footer-buttons.module.scss';
import { ButtonsProps } from '../../../shared/types/ButtonProps';
import { MenuButton } from '../../../shared/ui/button';

type Props = {
  className: string;
  data: ButtonsProps;
};

export const FooterButtons: React.FC<Props> = ({ className, data }) => {
  return (
    <div className={className}>
      <Link to={'/'} className={styles.text}>
        Back to top
      </Link>
      <MenuButton data={data} className={styles.button} />
    </div>
  );
};
