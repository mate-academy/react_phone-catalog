import classNames from 'classnames';
import styles from './SwiperPagination.module.scss';
import { useMSContext } from '../../context/MSContext';
import { getIndex } from '../../helpers/swiperHelpers';

type Props = {
  className: string;
  setByIndex: (index: number, animation?: boolean) => void;
};

export const SwiperPagination: React.FC<Props> = ({
  className,
  setByIndex,
}) => {
  const { listLength, offset, width, infinite, gap } = useMSContext();
  const arr = [];
  const length = listLength;
  const index = getIndex(offset.current, width.current, gap);

  const activeClass = () => {
    if (!infinite) {
      return index;
    } else {
      if (index < 2) {
        return listLength - 1;
      } else if (index > listLength + 1) {
        return 0;
      } else {
        return index - 2;
      }
    }
  };

  for (let i = 0; i < length; i++) {
    arr.push(i);
  }

  return (
    <div className={`${styles['line-pagination']} ${className}`}>
      {arr.map(li => (
        <div
          key={li}
          className={`${styles['line-container']}`}
          onClick={() => setByIndex(infinite ? li + 2 : li, true)}
        >
          <div
            className={classNames(styles['line-element'], {
              [styles['line-element__active']]: li === activeClass(),
            })}
          />
        </div>
      ))}
    </div>
  );
};
