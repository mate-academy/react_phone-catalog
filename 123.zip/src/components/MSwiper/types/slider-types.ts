export type SwiperData = {
  src: string;
  alt: string;
  href: string;
};
