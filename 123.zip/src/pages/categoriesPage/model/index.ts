export {
  useCategoriesContext,
  CategoriesProvider,
} from './context/categoriesContext';
