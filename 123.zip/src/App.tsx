import './App.scss';
import { Header } from './widgets/Header';

export const App = () => (
  <div className="App">
    <Header />
  </div>
);
