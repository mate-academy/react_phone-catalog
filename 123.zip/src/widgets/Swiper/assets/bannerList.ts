import { SwiperData } from '../types/swipe';

export const bannerList: SwiperData[] = [
  {
    src: './swiperbanner_1.webp',
    alt: 'buy iPhone 15',
    href: '#',
    id: 0,
  },
  {
    src: './swiperbanner_2.webp',
    alt: 'buy iPhone 16',
    href: '#',
    id: 1,
  },
  {
    src: './swiperbanner_3.webp',
    alt: 'About iPhone15',
    href: '#',
    id: 2,
  },
  {
    src: './swiperbanner_4.webp',
    alt: 'About iPhone16',
    href: '#',
    id: 3,
  },
];
