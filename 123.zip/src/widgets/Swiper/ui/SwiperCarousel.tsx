import { Link } from 'react-router-dom';
import { bannerList } from '../assets/bannerList';

export const SwiperCarousel = () => {
  const images = bannerList;

  return (
    <section className="swiper">
      <button className="swiper__button swiper__button-prev"></button>
      <div className="swiper__viewport">
        <div className="swiper__track">
          {images.map(i => (
            <Link key={i.id} className="swiper__slide" to={i.href}>
              <img
                className="swiper__image"
                src={i.src}
                alt={i.alt}
                loading={i.id === 0 ? 'eager' : 'lazy'}
              ></img>
            </Link>
          ))}
        </div>
      </div>
      <button className="swiper__button swiper__button-prev"></button>
      <div className="swiper__pagination"></div>
    </section>
  );
};
