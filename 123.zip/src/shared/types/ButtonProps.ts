export enum Path {
  Burger = '/burger-menu-16px.svg',
  Fav = '/fav-16px.svg',
  Cart = '/cart-16px.svg',
  Up = '/arrow-up.svg',
}

export enum ButtonNames {
  Burger = 'Open burger-menu',
  Fav = 'Open favorites',
  Cart = 'Open cart',
  Top = 'Go to top',
}

export type ButtonsProps = {
  name: ButtonNames;
  path: Path;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
};
