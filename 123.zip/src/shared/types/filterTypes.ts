type Order = ['Newest', 'Alphabetically', 'Cheapest'];

type PerPage = ['4', '8', '16', 'all'];

export { type Order, type PerPage };
