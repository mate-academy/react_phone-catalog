export enum Direction {
  LEFT = 'left',
  RIGHT = 'right',
}
