import { ButtonsProps } from '../../types/ButtonProps';
import styles from './button.module.scss';

type Props = {
  data: ButtonsProps;
  className: string;
};

export const MenuButton: React.FC<Props> = ({ data, className }) => {
  const { name, path } = data;

  return (
    <button
      className={`${styles['menu-button']} ${className}`}
      aria-label={`${name}`}
      style={{ backgroundImage: `url(/src/shared/icons${path})` }}
    />
  );
};
