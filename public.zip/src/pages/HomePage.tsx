import Content from '../components/Content/Content';
import Layout from './Layout';

const HomePage = () => {
  return (
    <Layout>
      <Content />
    </Layout>
  );
};

export default HomePage;
