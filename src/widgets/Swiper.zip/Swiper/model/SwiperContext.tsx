import { createContext, useContext, ReactNode, useState, useRef } from 'react';

type SwiperContextType = {
  offset: number;
  width: number;
  setOffset: React.Dispatch<React.SetStateAction<number>>;
  setWidth: React.Dispatch<React.SetStateAction<number>>;
  trackRef: React.RefObject<HTMLUListElement>;
  VPRef: React.RefObject<HTMLDivElement>;
};

const SwiperContext = createContext<SwiperContextType | null>(null);

export const useSwiperContext = () => {
  const context = useContext(SwiperContext);

  if (!context) {
    throw new Error('useSwiperContext must be used within SwiperProvider');
  }

  return context;
};

type SwiperProviderProps = {
  children: ReactNode;
};

export const SwiperProvider: React.FC<SwiperProviderProps> = ({ children }) => {
  const [offset, setOffset] = useState(0);
  const [width, setWidth] = useState(0);
  const trackRef = useRef<HTMLUListElement>(null);
  const VPRef = useRef<HTMLDivElement>(null);

  const value = {
    offset,
    width,
    setOffset,
    setWidth,
    trackRef,
    VPRef,
  };

  return (
    <SwiperContext.Provider value={value}>{children}</SwiperContext.Provider>
  );
};
