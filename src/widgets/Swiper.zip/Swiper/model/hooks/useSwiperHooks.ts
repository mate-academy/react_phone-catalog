import { useEffect, useRef, useState } from 'react';
import { SwiperMode } from '../types';
import { useSwiperContext } from '../SwiperContext';

export const useSwiperHooks = ({ mode }: { mode: SwiperMode }) => {
  const { VPRef, trackRef, offset, setOffset, width, setWidth } =
    useSwiperContext();
  const dragRef = useRef(0);
  const startXRef = useRef<number | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);

  useEffect(() => {
    if (!VPRef.current) {
      return;
    }

    const node = VPRef.current;

    setWidth(node.offsetWidth);
    const resizeObs = new ResizeObserver(() => setWidth(node.offsetWidth));

    resizeObs.observe(node);

    return () => resizeObs.disconnect();
  }, [VPRef, setWidth]);

  useEffect(() => {
    let id: number;
    const loop = () => {
      if (trackRef.current) {
        trackRef.current.style.transform = `translateX(${-offset + dragRef.current}px)`;
        trackRef.current.style.transition = isDragging
          ? 'none'
          : 'transform .35s ease-in-out';
      }

      id = requestAnimationFrame(loop);
    };

    loop();

    return () => cancelAnimationFrame(id);
  }, [offset, isDragging, trackRef]);

  const handleStart = (event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    const x = event.clientX;

    startXRef.current = x;
    dragRef.current = 0;
    setIsDragging(true);
  };

  const handleMove = (event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (startXRef.current === null) {
      return;
    }

    const x = event.clientX;

    dragRef.current = x - startXRef.current;
  };

  const handleEnd = (event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault();

    if (mode === SwiperMode.Free) {
      setOffset(prev => prev - dragRef.current);
    } else {
      const isSwipeLeft = dragRef.current < -width / 5;
      const isSwipeRight = dragRef.current > width / 5;

      setOffset(prev => {
        if (isSwipeLeft) {
          return prev + width;
        }

        if (isSwipeRight) {
          return prev - width;
        }

        return prev;
      });
    }

    startXRef.current = null;
    setIsDragging(false);

    requestAnimationFrame(() => {
      dragRef.current = 0;
    });
  };

  const handlers = {
    onPointerDown: handleStart,
    onPointerMove: handleMove,
    onPointerUp: handleEnd,
    onPointerCancel: handleEnd,
  };

  return { handlers };
};
