import classNames from 'classnames';
import styles from './SwiperPagination.module.scss';
import { useSwiperContext } from '../../model/SwiperContext';

type Props = {
  className: string;
  amount: number;
};

export const SwiperPagination: React.FC<Props> = ({ className, amount }) => {
  const { offset, setOffset, width } = useSwiperContext();
  const array = [];

  for (let i = 0; i < amount; i++) {
    array.push(i);
  }

  const handleClick = (id: number) => {
    setOffset(Math.round(width * id));
  };

  const activeId = Math.round(offset / width);

  return (
    <div className={`${styles['line-pagination']} ${className}`}>
      {array.map(li => (
        <div
          key={li}
          className={`${styles['line-container']}`}
          onPointerDown={() => handleClick(li)}
        >
          <div
            className={classNames(styles['line-element'], {
              [styles['line-element__active']]: activeId === li,
            })}
          />
        </div>
      ))}
    </div>
  );
};
