import { bannerList } from '../assets/bannerList';
import './Swiper.scss';
import { ArrDir, SwiperMode } from '../model/types';
import { SwiperButton } from './SwiperButton/SwiperButton';
import { SwiperPagination } from './SwiperPagination/SwiperPagination';
import { SwiperSlide } from './SwiperSlide/SwiperSlide';
import { useSwiperHooks } from '../model/hooks/useSwiperHooks';
import { useSwiperContext } from '../model/SwiperContext';

type Props = {
  mode: SwiperMode;
  buttons: boolean;
  pagination: boolean;
};

export const Swiper: React.FC<Props> = ({ mode, buttons, pagination }) => {
  const list = bannerList;
  const { VPRef, trackRef } = useSwiperContext();
  const { handlers } = useSwiperHooks({ mode });

  return (
    <div className="swiper">
      {buttons && (
        <SwiperButton className="swiper__button" dir={ArrDir.Previous} />
      )}
      <div className="swiper__viewport" ref={VPRef} {...handlers}>
        <ul className="swiper__track" ref={trackRef}>
          {list.map(li => (
            <SwiperSlide key={li.id} item={li} />
          ))}
        </ul>
      </div>
      {buttons && <SwiperButton className="swiper__button" dir={ArrDir.Next} />}
      {pagination && (
        <SwiperPagination
          className={'swiper__pagination'}
          amount={list.length}
        />
      )}
    </div>
  );
};
