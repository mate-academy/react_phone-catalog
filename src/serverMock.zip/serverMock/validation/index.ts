export { validate } from './validateEntryPoint';
