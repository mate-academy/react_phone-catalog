export {
  validateCatalogueBody,
  validateProdBody,
  validateBannerBody,
  validateAmountBody,
} from './validateGETBody';
export { validateBody } from './validateBodyMapper';
export { validateCheckoutBody, validateCartBody } from './validateCARTBody';
