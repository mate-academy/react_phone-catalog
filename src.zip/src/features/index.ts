export {
  useGlobalData,
  useGlobalActions,
  GlobalProvider,
} from './useGlobalStore/appContext';
export { useProdCard } from './useProductCard/useProdCard';
