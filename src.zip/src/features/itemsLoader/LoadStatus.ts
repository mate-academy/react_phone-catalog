export enum LoadStatus {
  LOADING = 'Loading...',
  ERROR = 'Error',
}
