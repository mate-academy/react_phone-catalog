export { ApiEndpoint } from './endPoints';
export {
  Processors,
  Resolutions,
  Ram,
  Colors,
  Screens,
  Cells,
  Capacity,
  Cameras,
  Category,
  type Description,
  PhoneZoom,
} from './itemsEnums';
