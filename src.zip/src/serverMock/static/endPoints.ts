enum ApiEndpoint {
  PRODUCTS = '/api/products.json',
  BANNERS = '/api/banners.json',
  ITEMS = '/api/items.json',
}

export { ApiEndpoint };
