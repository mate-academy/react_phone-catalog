enum SliderType {
  BANNER = 'banner',
  PRODUCT = 'product',
  CATALOGUE = 'catalogue',
}

export { SliderType };
