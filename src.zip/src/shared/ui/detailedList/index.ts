export { DetailedList } from './detailedList';
