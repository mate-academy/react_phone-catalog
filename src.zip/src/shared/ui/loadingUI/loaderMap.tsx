import { ReactElement } from 'react';
import { LoadingStates } from '../../../features/itemsLoader/loadItems';
import { Spinner } from '@ui/loadingUI/spinner';
import { ErrorElement } from '@ui/loadingUI/errorElement';

const createLoaderMap = (
  message: string,
  spinnerStyle: string,
  errorStyle: string,
): Record<LoadingStates, ReactElement> => ({
  [LoadingStates.LOADING]: <Spinner className={spinnerStyle} />,
  [LoadingStates.ERROR]: (
    <ErrorElement message={message} className={errorStyle} />
  ),
});

const loaderTextMap: Record<LoadingStates, string> = {
  [LoadingStates.LOADING]: 'Loading...',
  [LoadingStates.ERROR]: 'Something went wrong...',
};

export { createLoaderMap, loaderTextMap };
