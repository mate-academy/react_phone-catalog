import { ItemsAmount } from '@shared/api';
import { UrlParams } from '../types';

interface DropdownProps {
  title: string;
  searchParam: Exclude<UrlParams, UrlParams.PAGE>;
  defaultValue: string;
  names: string[];
}

const filter: DropdownProps = {
  title: 'Sort by',
  searchParam: UrlParams.SORT,
  defaultValue: 'Set the filter',
  names: ['Newest', 'Alphabetically', 'Cheapest'],
};

const perPage: DropdownProps = {
  title: 'Items on page',
  defaultValue: 'all',
  searchParam: UrlParams.PER_PAGE,
  names: [
    ItemsAmount.FOUR,
    ItemsAmount.EIGHT,
    ItemsAmount.SIXTEEN,
    ItemsAmount.ALL,
  ],
};

export { filter, perPage, type DropdownProps };
