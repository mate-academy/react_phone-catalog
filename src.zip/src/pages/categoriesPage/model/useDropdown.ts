import { useRef, useState } from 'react';
import { UrlParams } from '../types';
type Props = {
  setFilter: (param: UrlParams, value: string) => void;
};

export const useDropdown = (
  { setFilter }: Props,
  defaultFilter: string,
  searchParam: UrlParams,
) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [activeFilter, setActiveFilter] = useState<string>(defaultFilter);
  const button = useRef<HTMLButtonElement>(null);

  const onButtonClick = () => {
    setIsOpen(!isOpen);
  };

  const onOptionClick = (el: string) => {
    setActiveFilter(el);
    setFilter(searchParam, el);

    if (button.current) {
      button.current.blur();
    }

    onButtonClick();
  };

  return { isOpen, button, activeFilter, onButtonClick, onOptionClick };
};
