import { Category, get } from '@shared/api';
import { useEffect, useRef, useState } from 'react';
import { CatalogueProduct } from '@shared/types';
import { useFilter } from './useFilter';

export const useCatalogue = (category: Exclude<Category, Category.ALL>) => {
  const [items, setItems] = useState<CatalogueProduct[] | null | undefined>(
    null,
  );
  const pages = useRef<number>(1);
  const currentPage = useRef<number>(1);
  const failCount = useRef<number>(0);

  const { apiConf, setFilter, sort, page, perPage } = useFilter(category);

  const loadCatalogue = async () => {
    try {
      const res = await get.catalogue(apiConf);

      pages.current = res.pages;
      currentPage.current = res.currentPage;
      setItems(res.data);
    } catch (e) {
      if (failCount.current < 3) {
        failCount.current += 1;
        await new Promise(resolve =>
          setTimeout(resolve, 1000 * failCount.current),
        );

        return loadCatalogue();
      } else {
        setItems(undefined);
      }
    }
  };

  useEffect(() => {
    loadCatalogue();
  }, [sort, page, perPage]);

  return { items, setFilter };
};
