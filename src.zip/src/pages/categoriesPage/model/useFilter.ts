import { Category, ItemsAmount, Order } from '@shared/api';
import { useSearchParams } from 'react-router-dom';
import { UrlParams } from '../types';

const paramsMap = new Map<string, Order | ItemsAmount>([
  ['Newest', Order.AGE],
  ['Alphabetically', Order.TITLE],
  ['Cheapest', Order.PRICE_ASC],
  ['4', ItemsAmount.FOUR],
  ['8', ItemsAmount.EIGHT],
  ['16', ItemsAmount.SIXTEEN],
  ['all', ItemsAmount.ALL],
]);

export const useFilter = (category: Exclude<Category, Category.ALL>) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const sort = searchParams.get('sort') || '';
  const page = searchParams.get('page') || '';
  const perPage = searchParams.get('perPage') || '';

  const apiConf = {
    itemType: category,
    sortOrder: (paramsMap.get(sort) as Order) || Order.NONE,
    itemsOnPage: (paramsMap.get(perPage) as ItemsAmount) || ItemsAmount.ALL,
    page: +page || 1,
  };

  const setFilter = (param: UrlParams, value: string) => {
    setSearchParams(url => {
      {
        if (value === '' || value === ItemsAmount.ALL || value === '1') {
          url.delete(param);
        } else {
          const urlParam = paramsMap.get(value) as string;

          url.set(param, urlParam);
        }

        return url;
      }
    });
  };

  return { apiConf, setFilter, sort, page, perPage };
};
