import { Category } from '@shared/api';
import styles from './styles/categoriesPage.module.scss';
import { Dropdown, CataloguePagination, CatalogueGrid } from './ui';
import { useCatalogue, filter, pPage } from './model';
import { Breadcrumbs, ErrorElement, Spinner } from '@ui/index';
import { CatalogueProduct } from '@shared/types';

type Props = {
  category: Exclude<Category, Category.ALL>;
};

export const CategoriesPage = ({ category }: Props) => {
  const links = {
    name: category as string,
    to: category as string,
  };
  const { data, set, currentOrder, currentPerPage, pages, currentPage } =
    useCatalogue({
      category,
    });

  const getElement = (arg: CatalogueProduct[] | string | null) => {
    const style = styles.message;

    if (arg === null) {
      return <Spinner className={style} />;
    }

    switch (typeof arg) {
      case 'string':
        return <ErrorElement message={arg} className={style} />;
      case 'object':
        return <CatalogueGrid data={arg} />;
      default:
        return <ErrorElement message={'Unknown data type'} className={style} />;
    }
  };

  return (
    <section className={styles.container}>
      <nav aria-label="breadcrumb" className={styles.navigation}>
        <Breadcrumbs links={[links]} />
      </nav>

      <h1 className={styles.h1}>{category}</h1>
      <span className={styles.models}>{data.length}</span>
      <div className={styles.wrapper}>
        <Dropdown data={filter} setFilter={set.order} active={currentOrder} />
        <Dropdown data={pPage} setFilter={set.amount} active={currentPerPage} />
      </div>
      {getElement(data.items)}
      {pages.current > 1 && (
        <CataloguePagination
          pages={pages.current}
          currentPage={currentPage.current}
          setPage={set.page}
        />
      )}
    </section>
  );
};
