import { useProdCard } from '@features/index';
import styles from '../styles/catalogue.module.scss';
import { ProductCard } from '@entities/prodCard';
import { CatalogueProduct } from '@shared/types';

type Props = {
  data: CatalogueProduct[];
};
export const CatalogueGrid = ({ data }: Props) => {
  const { isIn, stateHandlers } = useProdCard();

  return (
    <ul className={styles.catalogue}>
      {data.map(el => (
        <ProductCard
          key={el.key}
          product={el}
          isIn={isIn}
          stateHandlers={stateHandlers}
        />
      ))}
    </ul>
  );
};
