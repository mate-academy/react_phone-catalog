import styles from '../styles/dropdownItem.module.scss';
import { ArrowIcon } from '@shared/icons';
import { DropdownProps } from '../model/dropdownConfig';
import { UrlParams } from '../types';
import { useDropdown } from '../model/useDropdown';

type Props = {
  data: DropdownProps;
  setFilter: (param: UrlParams, value: string) => void;
};

export const Dropdown = ({ data, setFilter }: Props) => {
  const { title, searchParam, defaultValue, names } = data;

  const { isOpen, button, activeFilter, onButtonClick, onOptionClick } =
    useDropdown({ setFilter }, defaultValue, searchParam);

  return (
    <div className={styles.container} aria-label="Catalogue filter">
      <span className={styles.title}>{title}</span>
      <button
        id={'sort'}
        ref={button}
        onClick={onButtonClick}
        className={styles.button}
      >
        {activeFilter}
        <ArrowIcon direction={isOpen ? null : 'down'} />
      </button>
      <ul
        style={isOpen ? { display: 'flex' } : { display: 'none' }}
        className={styles.options}
        role="listbox"
      >
        {names.map(el => (
          <li
            key={el}
            role="option"
            className={styles.options__item}
            onClick={() => onOptionClick(el)}
          >
            {el}
          </li>
        ))}
      </ul>
    </div>
  );
};
