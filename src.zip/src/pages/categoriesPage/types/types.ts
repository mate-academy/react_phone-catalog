enum UrlParams {
  SORT = 'sort',
  PAGE = 'page',
  PER_PAGE = 'perPage',
}

export { UrlParams };
