export { type Conf, type ProductProps } from './types';
export { organizeProps } from './organizeProps';
