export { Catalogue } from './catalogue';
export { Slider } from './sliders';
