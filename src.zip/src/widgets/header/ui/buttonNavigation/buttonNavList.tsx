import { uiLinksList } from '@widgets/header/model/';
import { HeaderButtonNavLink } from '.';
import styles from '../../styles/buttonNavigation.module.scss';

type Props = {
  closeMenu: () => void;
};
export const HeaderButtonNavigation = ({ closeMenu }: Props) => {
  return (
    <nav aria-label="User actions menu" className={styles['buttons-container']}>
      {uiLinksList.map(el => (
        <HeaderButtonNavLink
          key={el.to}
          ariaName={el.ariaName}
          to={el.to}
          icon={el.icon}
          closeMenu={closeMenu}
        />
      ))}
    </nav>
  );
};
