export { SliderPagination } from './sliderPagination';
export { ImagePagination } from './imagePagination';
