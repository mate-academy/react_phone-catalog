export { SliderPagination } from './sliderPagination';
