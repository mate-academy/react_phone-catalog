export { CatalogueSlider } from './catalogueSlider';
