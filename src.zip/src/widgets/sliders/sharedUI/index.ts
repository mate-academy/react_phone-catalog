export { SliderButtons } from './sliderButtons/sliderButton';
