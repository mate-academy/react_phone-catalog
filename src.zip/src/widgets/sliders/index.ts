export { Slider } from './slider';
