export { ProductSlider } from './productSlider';
