export const ProdSlider = () => {
  return <div></div>;
};
