export const ProdSkeleton = () => {
  return <div />;
};
