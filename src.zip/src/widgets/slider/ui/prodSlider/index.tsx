export { ProdSlider } from './prodSlider';
export { ProdSkeleton } from './prodSkeleton';
