export { HeroSlider, HeroSkeleton } from './heroSlider';
export { CatalogueSlider, CatalogueSkeleton } from './catalogueSlider';
export { ProdSlider, ProdSkeleton } from './prodSlider';
