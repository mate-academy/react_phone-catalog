type SkeletonProps = {
  error?: string;
};

export { type SkeletonProps };
