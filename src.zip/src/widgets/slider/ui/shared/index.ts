export { SliderButtons } from './button/sliderButton';
export { InfiniteBlockPagination } from './pagination/blockPagination';
