enum SliderMode {
  HERO = 'hero',
  CATALOGUE = 'catalogue',
  PRODUCT_CARD = 'productCard',
}

export { SliderMode };
